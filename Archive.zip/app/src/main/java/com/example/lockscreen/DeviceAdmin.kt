package com.example.lockscreen

import android.app.admin.DeviceAdminReceiver

class DeviceAdmin : DeviceAdminReceiver()